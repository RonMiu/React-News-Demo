import React from "react";
export default class MobileHeader extends React.Component {
  render(){
    return(
      <div>
        <footer class="footer">
          <span>&copy;&nbsp;2017 ReactNews. All Rights Reserved.</span>
        </footer>
      </div>
    )
  }
}
